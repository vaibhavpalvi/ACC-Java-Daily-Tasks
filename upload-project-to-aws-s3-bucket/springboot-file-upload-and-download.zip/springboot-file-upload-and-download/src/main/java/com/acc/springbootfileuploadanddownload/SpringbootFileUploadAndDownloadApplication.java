package com.acc.springbootfileuploadanddownload;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootFileUploadAndDownloadApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootFileUploadAndDownloadApplication.class, args);
	}

}
